# IT Inventory Management Tracker

A simple Excel-based IT inventory tracker designed to organize company equipment, software, support status, warranty dates, and asset reporting. This project was created as a portfolio-ready version of an IT asset tracking project for internship and entry-level technology roles.

## Project Overview

The tracker helps an IT team monitor technical assets such as laptops, desktops, software licenses, monitors, printers, network equipment, and mobile devices. It includes sample data, dropdown menus, formulas, conditional formatting, and a dashboard that summarizes asset status and categories.

## Key Features

- Tracks equipment, software, assigned user, department, location, purchase date, warranty expiration, value, status, and support priority
- Uses formulas to calculate days until warranty expiration
- Flags assets that need attention based on repair status, retired status, urgent support priority, or warranty timing
- Includes dropdown menus for common categories, departments, statuses, and priorities
- Uses conditional formatting to highlight items that need review
- Includes a dashboard with asset totals, status counts, category counts, and charts
- Includes sample CSV data that can be reused or imported into other tools

## Files Included

```text
IT_Inventory_Management_Tracker_GitHub/
├── IT_Inventory_Management_Tracker.xlsx
├── README.md
├── data/
│   └── sample_inventory.csv
├── docs/
│   └── dashboard_preview.png
├── src/
│   └── inventory_summary.py
└── .gitignore
```

## How to Use

1. Open `IT_Inventory_Management_Tracker.xlsx` in Microsoft Excel.
2. Go to the `Inventory Tracker` sheet.
3. Add or update assets in the table.
4. Use the dropdowns for category, department, status, and support priority.
5. Review the `Needs Attention` column for items that may need repair, renewal, or follow-up.
6. View the `Dashboard` sheet for a quick summary of inventory status.

## Dashboard Preview

![Dashboard Preview](docs/dashboard_preview.png)

## Skills Demonstrated

- Microsoft Excel
- IT asset tracking
- Data organization
- Formula-based reporting
- Dashboard creation
- Conditional formatting
- Basic data analysis
- Technical documentation

## Example Use Case

A small business or campus office can use this tracker to manage technology assets, see which devices are in use, monitor software license renewals, and identify assets that need IT support.

## Future Improvements

- Add barcode or QR code tracking
- Connect the workbook to Power BI for advanced dashboards
- Add automated email reminders for warranty expirations
- Convert the tracker into a web-based inventory system
- Add user permissions and asset checkout history

## Author

Michael Ejike  
Computer Information Systems - Cybersecurity Concentration  
Georgia State University  
LinkedIn: https://www.linkedin.com/in/michael-ejike1
