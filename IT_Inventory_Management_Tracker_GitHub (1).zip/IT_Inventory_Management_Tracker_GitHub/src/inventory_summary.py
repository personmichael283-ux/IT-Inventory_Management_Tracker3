"""Simple inventory summary script for the IT Inventory Management Tracker.

Run from the project root:
    python src/inventory_summary.py
"""

import csv
from collections import Counter
from pathlib import Path

DATA_FILE = Path(__file__).resolve().parents[1] / "data" / "sample_inventory.csv"


def load_inventory(path: Path):
    with path.open(newline="", encoding="utf-8") as file:
        return list(csv.DictReader(file))


def main():
    assets = load_inventory(DATA_FILE)
    status_counts = Counter(asset["Status"] for asset in assets)
    category_counts = Counter(asset["Category"] for asset in assets)
    total_value = sum(float(asset["Asset Value"] or 0) for asset in assets)

    print("IT Inventory Summary")
    print("====================")
    print(f"Total assets: {len(assets)}")
    print(f"Total asset value: ${total_value:,.2f}")

    print("\nAssets by status:")
    for status, count in status_counts.items():
        print(f"- {status}: {count}")

    print("\nAssets by category:")
    for category, count in category_counts.items():
        print(f"- {category}: {count}")


if __name__ == "__main__":
    main()
